#include <iostream>
#include <fstream>
#include <string>
#include<cstring>
#include <vector>
#include <unistd.h>
#include <cstdlib>
#include <signal.h>

using namespace std;

void SignalHandler(int sig){
cout << "señal recibida ALARMA ==>"<<sig<< endl;
}

int main (int argc,char** argv) 
{
    //CAPTURA LA SEÑAL Y REALIZA UNA FUNCIÓN    
    signal(SIGALRM, &SignalHandler);
    int i=0;
    while(true){
        sleep(1);
            cout << "HOLA MUNDO =>"<<i<<" --- "<< "MI PID : " << getpid() << endl;
            i++;
    }

}