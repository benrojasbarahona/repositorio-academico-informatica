#include <iostream>
#include <unistd.h>  
#include <stdio.h>  

using namespace std;

int main (int argc,char** argv) 
{
    printf("Executing ls command...\n");  
    execlp("ls", "ls", "-l", NULL);  

    return 0;
}