#include <iostream>

using namespace std;

int main (int argc,char** argv) 
{
    system("/bin/sh -c 'echo \"hola mundo \"'");  

    return 0;
}