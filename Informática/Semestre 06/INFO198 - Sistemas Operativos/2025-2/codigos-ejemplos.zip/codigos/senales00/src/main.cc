#include <iostream>
#include <fstream>
#include <string>
#include<cstring>
#include <vector>
#include <unistd.h>
#include <cstdlib>

using namespace std;

int main (int argc,char** argv) 
{

    int i=0;
    while(true){
        sleep(1);
            cout << "HOLA MUNDO =>"<<i << endl;
            //cout << "HOLA MUNDO =>"<<i<<" --- "<< "MI PID : " << getpid() << endl;
            i++;
    }

}