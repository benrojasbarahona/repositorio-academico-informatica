#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

#include <iostream>
#include <fstream>
#include <string>
#include<cstring>
#include <vector>
#include <unistd.h>
#include <cstdlib>

using namespace std;

int vGlobal=1;

int main(void)
{
    pid_t pidC;
    cout << "pid inicial "<<getpid()<< endl;

    pidC = fork();

    cout << "pid "<<getpid()<<" pidC ejecutandose "<<pidC<< endl;

    if(pidC>0){
        vGlobal=10;
    } else if(pidC==0){
        vGlobal=9;
    }
    else{
        cout<<"error"<<endl;
    }
    
    while(true){
        cout << "pid "<<getpid()<<" vGlobal ejecutandose >> "<<vGlobal<< endl;
        sleep(1);
    }
    
    return 0;
}