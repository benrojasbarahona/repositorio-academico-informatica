#include <iostream>
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

using namespace std;

int main (int argc,char** argv) 
{
    printf("Hello world -> My PID is %d\n", getpid());
    system("/bin/sh -c 'echo \"hola mundo PID $$\"'");  

    return 0;
}