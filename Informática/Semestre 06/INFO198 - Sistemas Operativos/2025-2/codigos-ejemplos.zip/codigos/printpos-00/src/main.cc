#include <iostream>
#include <cstdio>
#include <iostream>
#include <iomanip>
#include <string>



using namespace std;


int main (int argc,char** argv) 
{
cout << std::left  << std::setw(30) << "This is left aligned"
     << std::right << std::setw(30) << "This is right aligned";
    return 0;
}