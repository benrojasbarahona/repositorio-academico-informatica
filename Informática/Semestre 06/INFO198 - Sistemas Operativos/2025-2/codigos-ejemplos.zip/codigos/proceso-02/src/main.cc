#include <iostream>

using namespace std;

int main (int argc,char** argv) 
{
    system("export VARIABLECPP=1");  

    // system("/bin/sh -c 'echo \"########### \"'");  
    // system("/bin/sh -c 'echo \"ls de este directorio \"'");  
    // system("/bin/ls -l");  

    // system("/bin/sh -c 'echo \"########### \"'");  
    // system("/bin/sh -c 'echo \"ls de directorio raiz \"'");  
    // system("/bin/ls / -l");  

    return 0;
}