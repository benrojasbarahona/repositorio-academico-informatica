#include <iostream>
#include <fstream>
#include <string>
#include<cstring>
#include <vector>
#include <unistd.h>
#include <cstdlib>

using namespace std;

vector<string> split(const string& str, char delim) {
    vector<string> strings;
    size_t start;
    size_t end = 0;
    while ((start = str.find_first_not_of(delim, end)) != string::npos) {
        end = str.find(delim, start);
        strings.push_back(str.substr(start, end - start));
    }
    return strings;
}


        void dbRead(string dbFile){

            ifstream myfile;
            myfile.open(dbFile);
            string myline;
            if ( myfile.is_open() ) {
                while ( getline (myfile, myline) ) {
                    vector<string> userLine = split(myline,',');
                    cout<<"op="<<userLine[0]<<" ==>" <<userLine[1]<<endl;
                }
            }
            else {
                cout << "Couldn't open [ "<<dbFile<<" ] file \n";
            }
        }

int main (int argc,char** argv) 
{

    string dbMenu = getenv("DB_MENU");
    cout << "Your dbMenu is: " << dbMenu << '\n';

    dbRead(dbMenu);

}