#include <iostream>
#include <fstream>
#include <string>
#include<cstring>
#include <vector>
#include <unistd.h>
#include <cstdlib>
#include <signal.h>

using namespace std;

int main (int argc,char** argv) 
{

    //CAPTURA LA SEÑAL, PERO IGNORAR LA SEÑAL     
    signal(SIGALRM, SIG_IGN);
    int i=0;
    while(true){
        sleep(1);
            cout << "HOLA MUNDO =>"<<i<<" --- "<< "MI PID : " << getpid() << endl;
            i++;
    }

}